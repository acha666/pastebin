module aludec( input	 logic			opb5,
					input	 logic [2:0]	funct3,
					input  logic			funct7b5,
					input  logic [1:0]	ALUOp,
				   output logic [2:0]	ALUControl);

	
	// aluc[2] == 1; only if 10 010 xx 
	assign ALUControl[2] 
	= ALUOp[1]
	& ~ALUOp[0]
	& ~funct3[2]
	& funct3[1]
	& ~funct3[0]
	/*
	& opb5
	& funct7b5
	*/;
	
	// aluc[1] == 1; 10 110 xx || 10 111 xx -> 10 11(x) xx
	assign ALUControl[1] 
	= ALUOp[1]
	& ~ALUOp[0]
	& funct3[2]
	& funct3[1]
	/*
	& funct3[0]
	& opb5
	& funct7b5
	*/;
	
	// aluc[0] == 1; 01 xxx xx || 10 000 11 || 10 010 xx || 10 110 xx ->
	// 				  01 xxx xx || 10 000 11 || 10 x10 xx
	
	assign ALUControl[0] =
	(
		  ~ALUOp[1]
		& ALUOp[0]
		/*
		& funct3[2]
		& funct3[1]
		& funct3[0]
		& opb5
		& funct7b5
		*/
	) |
	(
		  ALUOp[1]
		& ~ALUOp[0]
		& ~funct3[2]
		& ~funct3[1]
		& ~funct3[0]
		& opb5
		& funct7b5
	) |
	(
		  ALUOp[1]
		& ~ALUOp[0]
		// & funct3[2]
		& funct3[1]
		& ~funct3[0]
		// & opb5
		// & funct7b5
	);

endmodule